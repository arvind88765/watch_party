import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'WatchParty — Watch Together',
  description: 'Stream local or cloud videos in sync with your friends.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-bg text-white min-h-screen">{children}</body>
    </html>
  );
}
