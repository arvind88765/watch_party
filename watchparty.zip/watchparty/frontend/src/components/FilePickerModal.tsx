'use client';
import { useState, useRef } from 'react';

const API = process.env.NEXT_PUBLIC_BACKEND_URL;
const MAX_CLOUD_MB = 4096; // 4 GB practical limit for cloud upload UI

interface Props {
  roomId: string;
  onLocalFile: (file: File) => void;
  onCloudFile: (url: string, name: string) => void;
  onClose: () => void;
}

export default function FilePickerModal({ roomId, onLocalFile, onCloudFile, onClose }: Props) {
  const [tab, setTab] = useState<'local' | 'cloud'>('local');
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const ACCEPTED = '.mkv,.mp4,.webm,.avi,.mov,.flv,.ts,.m2ts,.mp3,.flac,.aac,.ogg,.wav,.opus';

  function handleLocalFile(file: File) {
    onLocalFile(file);
  }

  async function handleCloudUpload(file: File) {
    if (file.size > MAX_CLOUD_MB * 1024 * 1024) {
      alert(`File too large for direct upload. Use local streaming instead.`);
      return;
    }
    setUploading(true);
    setProgress(0);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', `${API}/api/upload/${roomId}`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) setProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        if (xhr.status === 200) {
          const data = JSON.parse(xhr.responseText);
          onCloudFile(data.url, data.fileName);
        } else {
          alert('Upload failed: ' + xhr.responseText);
        }
        setUploading(false);
      };
      xhr.onerror = () => { alert('Upload error'); setUploading(false); };
      xhr.send(formData);
    } catch {
      setUploading(false);
    }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (!file) return;
    if (tab === 'local') handleLocalFile(file);
    else handleCloudUpload(file);
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="glass rounded-2xl p-6 w-full max-w-lg space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Load a file</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl leading-none">&times;</button>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-2 bg-bg rounded-xl p-1">
          {(['local', 'cloud'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${tab === t ? 'bg-accent text-white' : 'text-gray-400 hover:text-white'}`}
            >
              {t === 'local' ? 'Local File (Streaming)' : 'Upload to Cloud'}
            </button>
          ))}
        </div>

        {tab === 'local' && (
          <div className="space-y-3">
            <p className="text-sm text-gray-400">
              Pick a file from your computer. It streams directly from your browser to viewers via WebRTC — no upload, no processing. Fast even for large MKV files.
            </p>
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors ${dragOver ? 'border-accent bg-accent/10' : 'border-border hover:border-gray-500'}`}
            >
              <p className="text-4xl mb-2">🎬</p>
              <p className="text-gray-300">Drop file here or click to browse</p>
              <p className="text-xs text-gray-500 mt-1">MKV · MP4 · WebM · MP3 · FLAC · and more</p>
              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPTED}
                className="hidden"
                onChange={e => e.target.files?.[0] && handleLocalFile(e.target.files[0])}
              />
            </div>
          </div>
        )}

        {tab === 'cloud' && (
          <div className="space-y-3">
            <p className="text-sm text-gray-400">
              Upload your file to Google Cloud Storage. All viewers then stream from the cloud — great when you can't keep your browser tab open.
            </p>
            {uploading ? (
              <div className="space-y-2">
                <div className="h-3 bg-border rounded-full overflow-hidden">
                  <div className="h-full bg-accent transition-all" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-center text-sm text-gray-400">{progress}% uploaded…</p>
              </div>
            ) : (
              <div
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors ${dragOver ? 'border-accent bg-accent/10' : 'border-border hover:border-gray-500'}`}
              >
                <p className="text-4xl mb-2">☁️</p>
                <p className="text-gray-300">Drop file or click to upload</p>
                <p className="text-xs text-gray-500 mt-1">Up to 4 GB</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ACCEPTED}
                  className="hidden"
                  onChange={e => e.target.files?.[0] && handleCloudUpload(e.target.files[0])}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
