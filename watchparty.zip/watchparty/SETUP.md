# WatchParty — Complete Setup Guide
## For total beginners — step by step

---

## WHAT YOU'LL END UP WITH

| Part | Where | What it does |
|------|-------|--------------|
| Backend | Google Cloud Run | WebSocket server, room management, GCS uploads |
| Frontend | Vercel | The website your friends visit |
| Storage | Google Cloud Storage (optional) | Cloud file hosting |

---

## PART 1 — LOCAL TEST FIRST (make sure it works)

### Step 1 — Install tools
1. Install **Node.js 20** from https://nodejs.org
2. Install **Docker Desktop** from https://www.docker.com/products/docker-desktop

### Step 2 — Run locally
Open a terminal in the `watchparty` folder:

```bash
# Start everything with Docker Compose
docker-compose up --build
```

Open your browser at: **http://localhost:3000**

You should see the WatchParty homepage. Test creating a room.

---

## PART 2 — GOOGLE CLOUD SETUP

### Step 1 — Create a Google Cloud account
Go to https://console.cloud.google.com and sign in with your Google account.

### Step 2 — Create a new project
1. Click the project dropdown at the top (shows "Select a project")
2. Click **New Project**
3. Name it: `watchparty` → Click **Create**
4. Wait 30 seconds, then select the project from the dropdown

### Step 3 — Enable billing
Cloud Run needs billing enabled (you get $300 free credit).
1. In the left menu, click **Billing**
2. Follow prompts to add a payment method
3. Link your billing account to the `watchparty` project

### Step 4 — Enable required APIs
In Google Cloud Console, go to **APIs & Services → Enable APIs**. Enable these one by one:
- **Cloud Run API**
- **Cloud Build API**
- **Artifact Registry API**
- **Cloud Storage API** (only if you want cloud file uploads)

Or use the search bar at the top to find each one.

### Step 5 — Install Google Cloud CLI
Download from: https://cloud.google.com/sdk/docs/install

After installing, open a new terminal and run:
```bash
gcloud init
```
Follow the prompts:
- Sign in with your Google account
- Select your `watchparty` project

---

## PART 3 — DEPLOY BACKEND TO CLOUD RUN

### Step 1 — Deploy directly from source (easiest method)

Open a terminal, navigate to the `watchparty/backend` folder:

```bash
cd watchparty/backend

gcloud run deploy watchparty-backend \
  --source . \
  --region us-central1 \
  --platform managed \
  --allow-unauthenticated \
  --port 8080 \
  --min-instances 1 \
  --memory 512Mi \
  --set-env-vars="ALLOWED_ORIGINS=https://YOUR_APP.vercel.app"
```

**Replace `https://YOUR_APP.vercel.app` with your actual Vercel URL** (you'll get this in Part 4 — come back and update this later).

Wait 2-3 minutes. At the end you'll see:
```
Service URL: https://watchparty-backend-XXXX-uc.a.run.app
```

**SAVE THIS URL — you need it for Vercel.**

### Step 2 — Test the backend
Open your browser and go to: `https://watchparty-backend-XXXX-uc.a.run.app/health`

You should see: `{"ok":true}`

---

## PART 4 — DEPLOY FRONTEND TO VERCEL

### Step 1 — Create a Vercel account
Go to https://vercel.com and sign up (free).

### Step 2 — Install Vercel CLI
```bash
npm install -g vercel
```

### Step 3 — Deploy

Navigate to `watchparty/frontend` in your terminal:

```bash
cd watchparty/frontend
vercel
```

Answer the prompts:
- Set up and deploy? **Y**
- Which scope? (your username)
- Link to existing project? **N**
- Project name: `watchparty`
- Directory: `./` (press Enter)
- Override settings? **N**

You'll get a preview URL like `https://watchparty-abc123.vercel.app`

### Step 4 — Set environment variables in Vercel

Run these commands (replace the URL with your Cloud Run backend URL from Part 3):

```bash
vercel env add NEXT_PUBLIC_BACKEND_URL production
# Enter: https://watchparty-backend-XXXX-uc.a.run.app

vercel env add NEXT_PUBLIC_WS_URL production
# Enter: wss://watchparty-backend-XXXX-uc.a.run.app
```

> Note: Use `wss://` (not `ws://`) for WebSocket in production — Cloud Run uses HTTPS/WSS.

### Step 5 — Redeploy with env vars

```bash
vercel --prod
```

Your site is now live at: `https://watchparty.vercel.app` (or similar)

---

## PART 5 — UPDATE BACKEND WITH YOUR VERCEL URL

Now that you have your Vercel URL, update the backend's CORS setting:

```bash
gcloud run services update watchparty-backend \
  --region us-central1 \
  --update-env-vars="ALLOWED_ORIGINS=https://watchparty.vercel.app"
```

---

## PART 6 — (OPTIONAL) CLOUD FILE UPLOADS VIA GOOGLE CLOUD STORAGE

Skip this if you only want local file streaming (which is the main feature anyway).

### Step 1 — Create a GCS bucket
```bash
gcloud storage buckets create gs://watchparty-files-YOUR_NAME \
  --location=us-central1 \
  --uniform-bucket-level-access
```

### Step 2 — Create a service account for Cloud Run
```bash
gcloud iam service-accounts create watchparty-sa \
  --display-name="WatchParty Service Account"

# Give it permission to read/write to your bucket
gcloud storage buckets add-iam-policy-binding gs://watchparty-files-YOUR_NAME \
  --member="serviceAccount:watchparty-sa@YOUR_PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.objectAdmin"

# Attach service account to Cloud Run
gcloud run services update watchparty-backend \
  --region us-central1 \
  --service-account watchparty-sa@YOUR_PROJECT_ID.iam.gserviceaccount.com \
  --update-env-vars="GCS_BUCKET=watchparty-files-YOUR_NAME"
```

Replace `YOUR_NAME` and `YOUR_PROJECT_ID` with your actual values.

---

## PART 7 — HOW TO USE THE APP

### As Host:
1. Open your site (e.g., `https://watchparty.vercel.app`)
2. Click **Create Room**
3. A file picker appears — choose:
   - **Local File**: picks from your computer, streams to viewers in real-time
   - **Upload to Cloud**: uploads to GCS first, then everyone streams from cloud
4. Copy the share link and send to friends
5. You control play/pause/seek — everyone stays in sync

### As Viewer:
1. Open the invite link
2. Enter your name
3. Video starts automatically once the host presses play

### Features:
- **Sync**: play/pause/seek controls for host, everyone syncs
- **Chat**: real-time chat on the right side
- **Reactions**: emoji reactions that float up on screen
- **Subtitles**: click CC, load any .srt/.vtt/.ass file locally
- **Multi-audio**: if your MKV has multiple audio tracks, pick them from the dropdown
- **Volume Boost**: boost volume up to 3x (Web Audio API)
- **Playback Speed**: 0.25x to 2x
- **Revoke Link**: generate a new invite link, old one stops working
- **Fullscreen**: click fullscreen button or double-click video

---

## PART 8 — CUSTOM DOMAIN (optional)

In Vercel dashboard:
1. Go to your project → Settings → Domains
2. Add your domain (e.g., `watch.yourdomain.com`)
3. Follow the DNS instructions

---

## COST ESTIMATE

| Service | Free tier | After free tier |
|---------|-----------|-----------------|
| Cloud Run | 2M requests/month free | ~$0.00002/request |
| Cloud Storage | 5 GB free | $0.02/GB/month |
| Vercel | Unlimited (free plan) | Free forever for hobby |

For personal use watching with a few friends, **you'll likely pay $0/month**.

---

## TROUBLESHOOTING

**"Room not found"** — Backend isn't running or CORS is wrong. Check Cloud Run logs:
```bash
gcloud run services logs read watchparty-backend --region us-central1
```

**Video doesn't sync** — Check browser console for WebSocket errors. Make sure you're using `wss://` in production, not `ws://`.

**Friends can't see my video** — WebRTC needs a STUN server. The app uses Google's free STUN servers. If it still fails, you may need a TURN server (see `useWebRTC.ts` `ICE_SERVERS` array — add a free TURN server from https://www.metered.ca/tools/openrelay/).

**MKV plays but no sound** — Check if your MKV has an audio codec the browser supports (AAC, MP3, Opus, Vorbis). AC3/DTS audio won't play without transcoding. Use VLC to convert: `vlc input.mkv --sout '#transcode{acodec=mp3}:standard{dst=output.mkv}'`

**Upload fails** — GCS not configured. Either use Local File mode, or complete Part 6 of this guide.
