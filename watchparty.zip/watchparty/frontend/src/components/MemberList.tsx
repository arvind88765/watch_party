'use client';
import type { Member } from '@/app/room/[roomId]/RoomClient';

interface Props {
  members: Member[];
  myId: string;
}

export default function MemberList({ members, myId }: Props) {
  return (
    <div className="border-b border-border">
      <div className="px-3 py-2 text-sm font-semibold text-gray-400">
        Viewers ({members.length})
      </div>
      <ul className="max-h-36 overflow-y-auto px-3 pb-2 space-y-1">
        {members.map(m => (
          <li key={m.id} className="flex items-center gap-2 text-sm">
            <span className={`w-2 h-2 rounded-full ${m.id === myId ? 'bg-green-400' : 'bg-gray-500'}`} />
            <span className="flex-1 truncate text-gray-200">{m.name}</span>
            {m.isHost && <span className="text-xs text-accent-light">Host</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}
