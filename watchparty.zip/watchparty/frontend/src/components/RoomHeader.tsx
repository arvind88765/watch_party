'use client';
import { useState } from 'react';

interface Props {
  roomId: string;
  shareUrl: string;
  isHost: boolean;
  memberCount: number;
  onRevoke?: () => void;
}

export default function RoomHeader({ roomId, shareUrl, isHost, memberCount, onRevoke }: Props) {
  const [copied, setCopied] = useState(false);

  function copy() {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <header className="flex items-center gap-3 px-4 py-3 bg-surface border-b border-border">
      <a href="/" className="text-accent-light font-bold text-lg">WatchParty</a>
      <span className="text-gray-500 text-sm">#{roomId}</span>
      <div className="flex-1" />
      <span className="text-sm text-gray-400">{memberCount} watching</span>
      <div className="flex items-center gap-2">
        <input
          readOnly
          value={shareUrl}
          className="w-64 bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-gray-300 outline-none"
          onFocus={e => e.target.select()}
        />
        <button onClick={copy} className="btn-primary text-sm px-3 py-1.5">
          {copied ? 'Copied!' : 'Copy Link'}
        </button>
        {isHost && onRevoke && (
          <button
            onClick={onRevoke}
            className="btn-ghost text-sm px-3 py-1.5 text-red-400 border-red-800"
            title="Revoke link and generate a new one"
          >
            Revoke
          </button>
        )}
      </div>
    </header>
  );
}
