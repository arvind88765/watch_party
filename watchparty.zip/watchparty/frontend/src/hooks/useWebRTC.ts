import { useRef, useCallback } from 'react';
import type { Member } from '@/app/room/[roomId]/RoomClient';

interface Options {
  roomId: string;
  peerId: string;
  isHost: boolean;
  localFile: File | null;
  members: Member[];
  ws: WebSocket | null;
  send: (data: Record<string, unknown>) => void;
  videoRef: React.RefObject<HTMLVideoElement>;
}

const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
];

export function useWebRTC({ isHost, localFile, send, videoRef }: Options) {
  const peers = useRef<Map<string, RTCPeerConnection>>(new Map());

  const createPeer = useCallback((targetId: string, initiator: boolean) => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    peers.current.set(targetId, pc);

    pc.onicecandidate = (e) => {
      if (e.candidate) {
        send({ type: 'ICE', to: targetId, candidate: e.candidate });
      }
    };

    if (!initiator) {
      pc.ontrack = (e) => {
        if (videoRef.current && e.streams[0]) {
          videoRef.current.srcObject = e.streams[0];
        }
      };
    }

    return pc;
  }, [send, videoRef]);

  const startHostStream = useCallback(async (targetPeerId: string) => {
    if (!isHost || !localFile) return;

    const pc = createPeer(targetPeerId, true);

    // Stream local file as MediaSource via captureStream
    const video = videoRef.current;
    if (!video) return;

    // Capture the video element stream and add to peer connection
    // This streams whatever the host's video element is playing
    try {
      const stream = (video as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream?.();
      if (!stream) return;
      stream.getTracks().forEach(track => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      send({ type: 'OFFER', to: targetPeerId, sdp: pc.localDescription });
    } catch (err) {
      console.error('startHostStream error', err);
    }
  }, [isHost, localFile, createPeer, send, videoRef]);

  // Handle incoming WS signaling messages (called by RoomClient)
  const handleSignaling = useCallback(async (msg: Record<string, unknown>) => {
    const { type, from, sdp, candidate, to } = msg as {
      type: string; from: string; sdp?: RTCSessionDescriptionInit;
      candidate?: RTCIceCandidateInit; to?: string;
    };

    if (type === 'OFFER' && !isHost) {
      const pc = createPeer(from, false);
      await pc.setRemoteDescription(sdp!);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      send({ type: 'ANSWER', to: from, sdp: pc.localDescription });

    } else if (type === 'ANSWER' && isHost) {
      const pc = peers.current.get(from);
      if (pc) await pc.setRemoteDescription(sdp!);

    } else if (type === 'ICE') {
      const targetId = isHost ? from : from;
      const pc = peers.current.get(targetId);
      if (pc && candidate) await pc.addIceCandidate(candidate);
    }
  }, [isHost, createPeer, send]);

  const stopStream = useCallback(() => {
    peers.current.forEach(pc => pc.close());
    peers.current.clear();
  }, []);

  return { startHostStream, stopStream, handleSignaling };
}
