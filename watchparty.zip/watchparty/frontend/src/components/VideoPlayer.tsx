'use client';
import { useEffect, useRef, useState, useCallback } from 'react';
import type { RoomState } from '@/app/room/[roomId]/RoomClient';

interface Props {
  videoRef: React.RefObject<HTMLVideoElement>;
  isHost: boolean;
  localFile: File | null;
  cloudFileUrl: string | null;
  roomState: RoomState;
  onPlayPause: (playing: boolean, currentTime: number) => void;
  onSeek: (currentTime: number) => void;
}

function formatTime(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`
    : `${m}:${String(ss).padStart(2, '0')}`;
}

export default function VideoPlayer({
  videoRef, isHost, localFile, cloudFileUrl, roomState, onPlayPause, onSeek,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);

  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [boost, setBoost] = useState(1);        // 1x - 3x volume boost
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [subtitles, setSubtitles] = useState<SubtitleTrack[]>([]);
  const [activeSubtitle, setActiveSubtitle] = useState<number>(-1);
  const [audioTracks, setAudioTracks] = useState<string[]>([]);
  const [activeAudio, setActiveAudio] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const hideTimer = useRef<NodeJS.Timeout>();
  const localUrl = useRef<string>('');

  // Set video source
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (localFile) {
      if (localUrl.current) URL.revokeObjectURL(localUrl.current);
      localUrl.current = URL.createObjectURL(localFile);
      v.src = localUrl.current;
      v.load();
    } else if (cloudFileUrl) {
      v.src = cloudFileUrl;
      v.load();
    }
  }, [localFile, cloudFileUrl]);

  // Web Audio API for volume boost
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (!audioCtxRef.current) {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const gain = ctx.createGain();
      gainRef.current = gain;
      gain.connect(ctx.destination);
      const src = ctx.createMediaElementSource(v);
      sourceNodeRef.current = src;
      src.connect(gain);
    }
    if (gainRef.current) gainRef.current.gain.value = boost * volume * (muted ? 0 : 1);
  }, [boost, volume, muted]);

  // Sync with room state (for viewers)
  useEffect(() => {
    if (isHost) return;
    const v = videoRef.current;
    if (!v) return;
    const drift = Math.abs(v.currentTime - roomState.currentTime);
    if (drift > 1.5) v.currentTime = roomState.currentTime;
    if (roomState.playing && v.paused) v.play().catch(() => {});
    if (!roomState.playing && !v.paused) v.pause();
  }, [roomState, isHost]);

  // Video event listeners
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    const onTimeUpdate = () => {
      setCurrentTime(v.currentTime);
      if (v.buffered.length > 0) {
        setBuffered((v.buffered.end(v.buffered.length - 1) / v.duration) * 100 || 0);
      }
    };
    const onDurationChange = () => setDuration(v.duration || 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onLoadedMetadata = () => {
      setDuration(v.duration || 0);
      detectAudioTracks(v);
    };

    v.addEventListener('timeupdate', onTimeUpdate);
    v.addEventListener('durationchange', onDurationChange);
    v.addEventListener('play', onPlay);
    v.addEventListener('pause', onPause);
    v.addEventListener('loadedmetadata', onLoadedMetadata);

    return () => {
      v.removeEventListener('timeupdate', onTimeUpdate);
      v.removeEventListener('durationchange', onDurationChange);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('pause', onPause);
      v.removeEventListener('loadedmetadata', onLoadedMetadata);
    };
  }, []);

  function detectAudioTracks(v: HTMLVideoElement) {
    // AudioTrackList API (Chrome supports this for some formats)
    const atl = (v as HTMLVideoElement & { audioTracks?: AudioTrackList }).audioTracks;
    if (atl && atl.length > 1) {
      const names: string[] = [];
      for (let i = 0; i < atl.length; i++) {
        names.push(atl[i].label || atl[i].language || `Track ${i + 1}`);
      }
      setAudioTracks(names);
    }
  }

  function switchAudioTrack(idx: number) {
    const v = videoRef.current;
    if (!v) return;
    const atl = (v as HTMLVideoElement & { audioTracks?: AudioTrackList }).audioTracks;
    if (!atl) return;
    for (let i = 0; i < atl.length; i++) {
      atl[i].enabled = i === idx;
    }
    setActiveAudio(idx);
  }

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v || !isHost) return;
    if (v.paused) {
      v.play().then(() => onPlayPause(true, v.currentTime));
    } else {
      v.pause();
      onPlayPause(false, v.currentTime);
    }
  }, [isHost, onPlayPause, videoRef]);

  const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    if (!v || !isHost) return;
    const t = parseFloat(e.target.value);
    v.currentTime = t;
    onSeek(t);
  }, [isHost, onSeek, videoRef]);

  function loadSubtitleFile(file: File) {
    const url = URL.createObjectURL(file);
    const track: SubtitleTrack = { name: file.name, url };
    setSubtitles(prev => {
      const next = [...prev, track];
      setActiveSubtitle(next.length - 1);
      return next;
    });
  }

  function toggleFullscreen() {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      el.requestFullscreen().then(() => setFullscreen(true));
    } else {
      document.exitFullscreen().then(() => setFullscreen(false));
    }
  }

  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setShowControls(false), 3000);
  }, []);

  const progress = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full bg-black group select-none"
      onMouseMove={resetHideTimer}
      onMouseLeave={() => setShowControls(false)}
    >
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        preload="metadata"
        onDoubleClick={toggleFullscreen}
        onClick={isHost ? togglePlay : undefined}
        crossOrigin="anonymous"
      >
        {subtitles.map((st, i) => (
          <track
            key={st.url}
            kind="subtitles"
            src={st.url}
            label={st.name}
            default={i === activeSubtitle}
          />
        ))}
      </video>

      {/* No source state */}
      {!localFile && !cloudFileUrl && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-500">
          {isHost ? 'Pick a file to start' : 'Waiting for host to load a file…'}
        </div>
      )}

      {/* Controls overlay */}
      <div className={`absolute bottom-0 left-0 right-0 transition-opacity duration-300 ${showControls || !playing ? 'opacity-100' : 'opacity-0'}`}>
        <div className="bg-gradient-to-t from-black/90 to-transparent px-4 pt-8 pb-3 space-y-2">
          {/* Progress */}
          <div className="relative h-1 bg-white/20 rounded-full cursor-pointer">
            <div className="absolute h-full bg-white/30 rounded-full" style={{ width: `${buffered}%` }} />
            <div className="absolute h-full bg-accent rounded-full" style={{ width: `${progress}%` }} />
            {isHost && (
              <input
                type="range" min={0} max={duration || 1} step={0.5}
                value={currentTime}
                onChange={handleSeek}
                className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
              />
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Play/Pause */}
            {isHost && (
              <button onClick={togglePlay} className="text-white hover:text-accent-light">
                {playing ? <PauseIcon /> : <PlayIcon />}
              </button>
            )}

            {/* Time */}
            <span className="text-xs text-gray-300 font-mono">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>

            <div className="flex-1" />

            {/* Volume */}
            <div className="flex items-center gap-1">
              <button onClick={() => setMuted(m => !m)} className="text-white hover:text-accent-light">
                {muted || volume === 0 ? <MuteIcon /> : <VolumeIcon />}
              </button>
              <input
                type="range" min={0} max={1} step={0.05} value={muted ? 0 : volume}
                onChange={e => { setVolume(+e.target.value); setMuted(false); }}
                className="w-20"
              />
            </div>

            {/* Volume Boost */}
            <div className="flex items-center gap-1 text-xs text-gray-300">
              <span>Boost</span>
              <input
                type="range" min={1} max={3} step={0.25} value={boost}
                onChange={e => setBoost(+e.target.value)}
                className="w-16"
                title={`${boost}x boost`}
              />
              <span className="w-7">{boost}x</span>
            </div>

            {/* Playback speed */}
            {isHost && (
              <select
                value={playbackRate}
                onChange={e => {
                  const r = +e.target.value;
                  setPlaybackRate(r);
                  if (videoRef.current) videoRef.current.playbackRate = r;
                }}
                className="bg-surface border border-border text-white text-xs rounded px-1 py-0.5"
              >
                {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map(r => (
                  <option key={r} value={r}>{r}x</option>
                ))}
              </select>
            )}

            {/* Subtitle loader */}
            <label className="text-xs text-gray-300 hover:text-white cursor-pointer" title="Load subtitle file (.srt/.vtt/.ass)">
              CC
              <input
                type="file"
                accept=".srt,.vtt,.ass,.ssa"
                className="hidden"
                onChange={e => e.target.files?.[0] && loadSubtitleFile(e.target.files[0])}
              />
            </label>

            {/* Audio track selector */}
            {audioTracks.length > 1 && (
              <select
                value={activeAudio}
                onChange={e => switchAudioTrack(+e.target.value)}
                className="bg-surface border border-border text-white text-xs rounded px-1 py-0.5"
                title="Audio track"
              >
                {audioTracks.map((t, i) => <option key={i} value={i}>{t}</option>)}
              </select>
            )}

            {/* Fullscreen */}
            <button onClick={toggleFullscreen} className="text-white hover:text-accent-light">
              {fullscreen ? <ExitFsIcon /> : <FsIcon />}
            </button>
          </div>
        </div>
      </div>

      {/* Viewer badge */}
      {!isHost && (
        <div className="absolute top-3 left-3 bg-black/60 text-xs text-gray-300 px-2 py-1 rounded">
          Viewer
        </div>
      )}
    </div>
  );
}

interface SubtitleTrack { name: string; url: string; }

function PlayIcon() {
  return <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>;
}
function PauseIcon() {
  return <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>;
}
function VolumeIcon() {
  return <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/></svg>;
}
function MuteIcon() {
  return <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>;
}
function FsIcon() {
  return <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>;
}
function ExitFsIcon() {
  return <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>;
}
