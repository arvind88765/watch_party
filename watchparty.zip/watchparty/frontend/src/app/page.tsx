'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

const API = process.env.NEXT_PUBLIC_BACKEND_URL;

export default function Home() {
  const router = useRouter();
  const [creating, setCreating] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [joinErr, setJoinErr] = useState('');

  async function createRoom() {
    setCreating(true);
    try {
      const res = await fetch(`${API}/api/rooms`, { method: 'POST' });
      const data = await res.json();
      // Redirect host to room with their token
      router.push(`/room/${data.roomId}?token=${data.linkToken}&host=1`);
    } catch {
      setCreating(false);
      alert('Failed to create room. Is the backend running?');
    }
  }

  function joinByLink() {
    const trimmed = joinCode.trim();
    if (!trimmed) return;
    // Accept full URL or just roomId/token
    try {
      const url = new URL(trimmed);
      router.push(url.pathname + url.search);
    } catch {
      // Might be roomId?token=... format
      if (trimmed.includes('?')) {
        router.push(`/room/${trimmed}`);
      } else {
        setJoinErr('Paste the full invite link');
      }
    }
  }

  return (
    <main className="flex flex-col items-center justify-center min-h-screen px-4">
      <div className="glass rounded-2xl p-10 max-w-md w-full text-center space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-accent-light">WatchParty</h1>
          <p className="text-gray-400 mt-2">Stream any file. Watch together.</p>
        </div>

        <button onClick={createRoom} disabled={creating} className="btn-primary w-full text-lg">
          {creating ? 'Creating room…' : '+ Create Room'}
        </button>

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-border" />
          <span className="text-gray-500 text-sm">or join</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <div className="space-y-2">
          <input
            value={joinCode}
            onChange={e => { setJoinCode(e.target.value); setJoinErr(''); }}
            onKeyDown={e => e.key === 'Enter' && joinByLink()}
            placeholder="Paste invite link here…"
            className="w-full bg-surface border border-border rounded-xl px-4 py-3 outline-none focus:border-accent text-white"
          />
          {joinErr && <p className="text-red-400 text-sm">{joinErr}</p>}
          <button onClick={joinByLink} className="btn-ghost w-full">
            Join Room
          </button>
        </div>

        <p className="text-gray-500 text-xs">
          Supports MKV · MP4 · WebM · MP3 · AAC · FLAC · SRT · ASS subtitles
        </p>
      </div>
    </main>
  );
}
