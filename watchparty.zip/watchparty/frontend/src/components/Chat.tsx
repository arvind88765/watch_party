'use client';
import { useState, useRef, useEffect } from 'react';
import type { ChatMsg } from '@/app/room/[roomId]/RoomClient';
import clsx from 'clsx';

interface Props {
  messages: ChatMsg[];
  onSend: (text: string) => void;
  myId: string;
}

export default function Chat({ messages, onSend, myId }: Props) {
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function submit() {
    const t = text.trim();
    if (!t) return;
    onSend(t);
    setText('');
  }

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <div className="px-3 py-2 border-b border-border text-sm font-semibold text-gray-400">Chat</div>
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
        {messages.map(m => (
          <div key={m.id}>
            {m.peerId === '__system__' ? (
              <p className="text-center text-xs text-gray-500">{m.text}</p>
            ) : (
              <div className={clsx('flex flex-col', m.peerId === myId ? 'items-end' : 'items-start')}>
                <span className="text-xs text-gray-500 mb-0.5">{m.userName}</span>
                <div className={clsx(
                  'rounded-2xl px-3 py-1.5 text-sm max-w-[90%] break-words',
                  m.peerId === myId
                    ? 'bg-accent text-white rounded-br-sm'
                    : 'bg-surface text-gray-200 rounded-bl-sm'
                )}>
                  {m.text}
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="px-3 py-2 border-t border-border flex gap-2">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && submit()}
          placeholder="Say something…"
          className="flex-1 bg-surface border border-border rounded-xl px-3 py-2 text-sm outline-none focus:border-accent"
        />
        <button onClick={submit} className="btn-primary px-3 py-2 text-sm">Send</button>
      </div>
    </div>
  );
}
