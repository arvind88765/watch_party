'use client';
import { useEffect, useRef, useState, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import VideoPlayer from '@/components/VideoPlayer';
import Chat from '@/components/Chat';
import MemberList from '@/components/MemberList';
import RoomHeader from '@/components/RoomHeader';
import FilePickerModal from '@/components/FilePickerModal';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useWebRTC } from '@/hooks/useWebRTC';

const API = process.env.NEXT_PUBLIC_BACKEND_URL;

export interface Member { id: string; name: string; isHost: boolean; }
export interface ChatMsg { peerId: string; userName: string; text: string; id: number; }
export interface RoomState { playing: boolean; currentTime: number; }

export default function RoomClient({ roomId }: { roomId: string }) {
  const params = useSearchParams();
  const token = params.get('token') ?? '';
  const isHostInit = params.get('host') === '1';

  const [peerId, setPeerId] = useState('');
  const [isHost, setIsHost] = useState(isHostInit);
  const [members, setMembers] = useState<Member[]>([]);
  const [chatMsgs, setChatMsgs] = useState<ChatMsg[]>([]);
  const [roomState, setRoomState] = useState<RoomState>({ playing: false, currentTime: 0 });
  const [linkToken, setLinkToken] = useState(token);
  const [sourceType, setSourceType] = useState<'local' | 'cloud'>('local');
  const [cloudFileUrl, setCloudFileUrl] = useState<string | null>(null);
  const [cloudFileName, setCloudFileName] = useState<string | null>(null);
  const [localFile, setLocalFile] = useState<File | null>(null);
  const [showFilePicker, setShowFilePicker] = useState(false);
  const [reactions, setReactions] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [error, setError] = useState('');
  const msgCounter = useRef(0);
  const reactionCounter = useRef(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const { ws, send, connected } = useWebSocket({
    url: `${process.env.NEXT_PUBLIC_WS_URL}/ws`,
    onMessage: handleWsMessage,
  });

  const { startHostStream, stopStream } = useWebRTC({
    roomId,
    peerId,
    isHost,
    localFile,
    members,
    ws: ws.current,
    send,
    videoRef,
  });

  // Join room once WS is connected
  useEffect(() => {
    if (!connected) return;
    const name = sessionStorage.getItem('wp_name') || promptName();
    sessionStorage.setItem('wp_name', name);
    send({ type: 'JOIN', roomId, token: linkToken, userName: name });
  }, [connected]);

  function promptName() {
    return prompt('Your display name?') || 'Guest';
  }

  function handleWsMessage(msg: Record<string, unknown>) {
    switch (msg.type) {
      case 'JOINED': {
        setPeerId(msg.peerId as string);
        setIsHost(msg.isHost as boolean);
        setMembers(msg.members as Member[]);
        setSourceType(msg.sourceType as 'local' | 'cloud');
        if (msg.cloudFileUrl) setCloudFileUrl(msg.cloudFileUrl as string);
        if (msg.cloudFileName) setCloudFileName(msg.cloudFileName as string);
        const st = msg.roomState as RoomState;
        setRoomState(st);
        if (!(msg.isHost as boolean)) {
          send({ type: 'REQUEST_SYNC' });
        } else {
          // Host sees file picker if no file yet
          setShowFilePicker(true);
        }
        break;
      }
      case 'PEER_JOINED':
        setMembers(prev => [...prev.filter(m => m.id !== (msg.peerId as string)),
          { id: msg.peerId as string, name: msg.userName as string, isHost: msg.isHost as boolean }]);
        addChatSystem(`${msg.userName} joined`);
        // If host, send WebRTC offer to new peer
        if (isHost) startHostStream(msg.peerId as string);
        break;
      case 'PEER_LEFT':
        setMembers(prev => prev.filter(m => m.id !== msg.peerId));
        addChatSystem(`A viewer left`);
        break;
      case 'PLAY_STATE':
        setRoomState({ playing: msg.playing as boolean, currentTime: msg.currentTime as number });
        syncVideo(msg.playing as boolean, msg.currentTime as number);
        break;
      case 'SEEK':
        if (videoRef.current) videoRef.current.currentTime = msg.currentTime as number;
        break;
      case 'SYNC_RESPONSE_RELAY':
        if (!isHost) {
          syncVideo(msg.playing as boolean, msg.currentTime as number);
        }
        break;
      case 'SYNC_REQUEST':
        if (isHost && videoRef.current) {
          send({
            type: 'SYNC_RESPONSE_RELAY',
            to: msg.from,
            playing: !videoRef.current.paused,
            currentTime: videoRef.current.currentTime,
          });
        }
        break;
      case 'CHAT':
        setChatMsgs(prev => [...prev, {
          id: ++msgCounter.current,
          peerId: msg.peerId as string,
          userName: msg.userName as string,
          text: msg.text as string,
        }]);
        break;
      case 'REACTION':
        popReaction(msg.emoji as string);
        break;
      case 'LINK_REVOKED':
        setLinkToken(msg.linkToken as string);
        break;
      case 'ERROR':
        setError(msg.message as string);
        break;
    }
  }

  function syncVideo(playing: boolean, currentTime: number) {
    const v = videoRef.current;
    if (!v) return;
    const drift = Math.abs(v.currentTime - currentTime);
    if (drift > 1) v.currentTime = currentTime;
    if (playing && v.paused) v.play().catch(() => {});
    if (!playing && !v.paused) v.pause();
  }

  function addChatSystem(text: string) {
    setChatMsgs(prev => [...prev, { id: ++msgCounter.current, peerId: '__system__', userName: '', text }]);
  }

  function popReaction(emoji: string) {
    const id = ++reactionCounter.current;
    const x = Math.random() * 80 + 10;
    setReactions(prev => [...prev, { id, emoji, x }]);
    setTimeout(() => setReactions(prev => prev.filter(r => r.id !== id)), 2000);
  }

  const onHostPlayPause = useCallback((playing: boolean, currentTime: number) => {
    send({ type: 'PLAY_STATE', playing, currentTime });
    setRoomState({ playing, currentTime });
  }, [send]);

  const onHostSeek = useCallback((currentTime: number) => {
    send({ type: 'SEEK', currentTime });
  }, [send]);

  const sendChat = useCallback((text: string) => {
    send({ type: 'CHAT', text });
  }, [send]);

  const sendReaction = useCallback((emoji: string) => {
    send({ type: 'REACTION', emoji });
    popReaction(emoji);
  }, [send]);

  const revokeLink = useCallback(async () => {
    const res = await fetch(`${API}/api/rooms/${roomId}/revoke`, { method: 'POST' });
    const data = await res.json();
    setLinkToken(data.linkToken);
  }, [roomId]);

  const shareUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/room/${roomId}?token=${linkToken}`
    : '';

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="glass rounded-2xl p-8 text-center space-y-4">
          <p className="text-red-400 text-lg">{error}</p>
          <a href="/" className="btn-primary inline-block">Back to Home</a>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <RoomHeader
        roomId={roomId}
        shareUrl={shareUrl}
        isHost={isHost}
        memberCount={members.length}
        onRevoke={isHost ? revokeLink : undefined}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Main video area */}
        <div className="flex-1 flex flex-col relative overflow-hidden">
          <div className="flex-1 relative bg-black">
            <VideoPlayer
              videoRef={videoRef}
              isHost={isHost}
              localFile={localFile}
              cloudFileUrl={cloudFileUrl}
              roomState={roomState}
              onPlayPause={onHostPlayPause}
              onSeek={onHostSeek}
            />
            {/* Reactions overlay */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {reactions.map(r => (
                <span
                  key={r.id}
                  className="reaction-pop"
                  style={{ left: `${r.x}%`, bottom: '80px' }}
                >
                  {r.emoji}
                </span>
              ))}
            </div>
          </div>

          {/* Reaction bar */}
          <div className="flex items-center gap-2 px-4 py-2 bg-surface border-t border-border">
            {['👍','❤️','😂','😮','🔥','🎉','👏','💯'].map(e => (
              <button
                key={e}
                onClick={() => sendReaction(e)}
                className="text-xl hover:scale-125 transition-transform"
                title={e}
              >
                {e}
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 flex flex-col border-l border-border">
          <MemberList members={members} myId={peerId} />
          <Chat messages={chatMsgs} onSend={sendChat} myId={peerId} />
        </div>
      </div>

      {showFilePicker && isHost && (
        <FilePickerModal
          roomId={roomId}
          onLocalFile={(file) => {
            setLocalFile(file);
            setSourceType('local');
            setShowFilePicker(false);
          }}
          onCloudFile={(url, name) => {
            setCloudFileUrl(url);
            setCloudFileName(name);
            setSourceType('cloud');
            setShowFilePicker(false);
          }}
          onClose={() => setShowFilePicker(false)}
        />
      )}
    </div>
  );
}
