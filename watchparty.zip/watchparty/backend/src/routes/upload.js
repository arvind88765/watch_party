import { Router } from 'express';
import multer from 'multer';
import { Storage } from '@google-cloud/storage';
import { rooms } from '../store.js';

const router = Router();

const GCS_BUCKET = process.env.GCS_BUCKET;

let storage;
if (GCS_BUCKET) {
  storage = new Storage();
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 * 1024 }, // 20 GB
});

// Upload file to GCS, associate with room
router.post('/:roomId', upload.single('file'), async (req, res) => {
  if (!storage || !GCS_BUCKET) {
    return res.status(503).json({ error: 'Cloud storage not configured' });
  }

  const room = rooms.get(req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Room not found' });

  const file = req.file;
  if (!file) return res.status(400).json({ error: 'No file provided' });

  try {
    const bucket = storage.bucket(GCS_BUCKET);
    const dest = `rooms/${req.params.roomId}/${Date.now()}-${file.originalname}`;
    const gcsFile = bucket.file(dest);

    await gcsFile.save(file.buffer, {
      contentType: file.mimetype,
      resumable: false,
    });

    // Make signed URL valid for 24h
    const [url] = await gcsFile.getSignedUrl({
      action: 'read',
      expires: Date.now() + 24 * 60 * 60 * 1000,
    });

    room.sourceType = 'cloud';
    room.cloudFileUrl = url;
    room.cloudFileName = file.originalname;

    res.json({ url, fileName: file.originalname });
  } catch (err) {
    console.error('GCS upload error:', err);
    res.status(500).json({ error: 'Upload failed' });
  }
});

export const uploadRouter = router;
