import { customAlphabet } from 'nanoid';
import { rooms } from '../store.js';

const nanoid = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 8);
const nanoid16 = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 16);

// Message types (client → server)
// JOIN          { type, roomId, token, userName }
// OFFER         { type, to, sdp }         WebRTC offer (host → peer)
// ANSWER        { type, to, sdp }         WebRTC answer (peer → host)
// ICE           { type, to, candidate }   ICE candidate relay
// PLAY_STATE    { type, playing, currentTime }   host controls
// SEEK          { type, currentTime }
// CHAT          { type, text }
// REQUEST_SYNC  { type }                  new joiner asks host for current time
// REACTION      { type, emoji }
// REVOKE_LINK   { type }                  host rotates link token

// Message types (server → client)
// JOINED        { type, peerId, isHost, members[], roomState }
// PEER_JOINED   { type, peerId, userName }
// PEER_LEFT     { type, peerId }
// OFFER / ANSWER / ICE  (relayed unchanged)
// PLAY_STATE    (broadcast from host)
// SYNC_RESPONSE { type, playing, currentTime } (host → specific peer)
// CHAT          { type, peerId, userName, text }
// REACTION      { type, peerId, emoji }
// LINK_REVOKED  { type, linkToken }       new token after revoke
// ERROR         { type, message }

export function handleWS(ws, req, wss) {
  const peerId = nanoid();
  let roomId = null;
  let isHost = false;
  let userName = 'Guest';

  ws.peerId = peerId;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {
      case 'JOIN': return handleJoin(msg);
      case 'OFFER':
      case 'ANSWER':
      case 'ICE':
      case 'SYNC_RESPONSE_RELAY': return relay(msg);
      case 'PLAY_STATE': return handlePlayState(msg);
      case 'SEEK': return handleSeek(msg);
      case 'CHAT': return handleChat(msg);
      case 'REQUEST_SYNC': return handleRequestSync(msg);
      case 'REACTION': return handleReaction(msg);
      case 'REVOKE_LINK': return handleRevoke();
    }
  });

  ws.on('close', () => {
    if (!roomId) return;
    const room = rooms.get(roomId);
    if (!room) return;
    room.members.delete(peerId);
    broadcast(room, { type: 'PEER_LEFT', peerId });
    if (isHost && room.members.size === 0) {
      // clean up empty rooms after 10min
      setTimeout(() => {
        if (rooms.get(roomId)?.members.size === 0) rooms.delete(roomId);
      }, 10 * 60 * 1000);
    }
  });

  function handleJoin(msg) {
    const room = rooms.get(msg.roomId);
    if (!room) return send({ type: 'ERROR', message: 'Room not found' });
    if (room.linkToken !== msg.token) return send({ type: 'ERROR', message: 'Invalid link token' });

    roomId = msg.roomId;
    userName = (msg.userName || 'Guest').slice(0, 32);
    isHost = room.members.size === 0;

    if (isHost) room.hostId = peerId;

    room.members.set(peerId, { id: peerId, name: userName, ws, isHost });

    const memberList = [...room.members.values()].map(m => ({ id: m.id, name: m.name, isHost: m.isHost }));

    send({
      type: 'JOINED',
      peerId,
      isHost,
      members: memberList,
      roomState: room.state,
      sourceType: room.sourceType,
      cloudFileUrl: room.cloudFileUrl,
      cloudFileName: room.cloudFileName,
    });

    broadcast(room, { type: 'PEER_JOINED', peerId, userName, isHost }, peerId);
  }

  function relay(msg) {
    const room = rooms.get(roomId);
    if (!room) return;
    const target = room.members.get(msg.to);
    if (!target) return;
    safeSend(target.ws, { ...msg, from: peerId });
  }

  function handlePlayState(msg) {
    if (!isHost) return;
    const room = rooms.get(roomId);
    if (!room) return;
    room.state = { playing: msg.playing, currentTime: msg.currentTime, updatedAt: Date.now() };
    broadcast(room, { type: 'PLAY_STATE', playing: msg.playing, currentTime: msg.currentTime }, peerId);
  }

  function handleSeek(msg) {
    if (!isHost) return;
    const room = rooms.get(roomId);
    if (!room) return;
    room.state.currentTime = msg.currentTime;
    room.state.updatedAt = Date.now();
    broadcast(room, { type: 'SEEK', currentTime: msg.currentTime }, peerId);
  }

  function handleChat(msg) {
    const room = rooms.get(roomId);
    if (!room) return;
    broadcast(room, { type: 'CHAT', peerId, userName, text: (msg.text || '').slice(0, 500) });
  }

  function handleRequestSync(_msg) {
    const room = rooms.get(roomId);
    if (!room) return;
    const host = room.members.get(room.hostId);
    if (!host) return;
    safeSend(host.ws, { type: 'SYNC_REQUEST', from: peerId });
  }

  function handleReaction(msg) {
    const room = rooms.get(roomId);
    if (!room) return;
    broadcast(room, { type: 'REACTION', peerId, emoji: msg.emoji });
  }

  function handleRevoke() {
    if (!isHost) return;
    const room = rooms.get(roomId);
    if (!room) return;
    room.linkToken = nanoid16();
    broadcast(room, { type: 'LINK_REVOKED', linkToken: room.linkToken });
  }

  function send(data) {
    safeSend(ws, data);
  }
}

function broadcast(room, data, excludePeerId = null) {
  for (const [id, m] of room.members) {
    if (id === excludePeerId) continue;
    safeSend(m.ws, data);
  }
}

function safeSend(ws, data) {
  if (ws.readyState === 1) ws.send(JSON.stringify(data));
}
