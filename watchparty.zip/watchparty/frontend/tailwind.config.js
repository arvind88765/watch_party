/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0f0f13',
        surface: '#1a1a24',
        border: '#2a2a38',
        accent: '#7c3aed',
        'accent-light': '#a78bfa',
      },
    },
  },
  plugins: [],
};
