import { Router } from 'express';
import { customAlphabet } from 'nanoid';
import { rooms } from '../store.js';

const nanoid = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 10);

export const roomRouter = Router();

// Create room
roomRouter.post('/', (req, res) => {
  const id = nanoid();
  const linkToken = nanoid(16);
  rooms.set(id, {
    id,
    hostId: null,        // set when host WS connects
    createdAt: Date.now(),
    linkToken,
    sourceType: 'local',
    cloudFileUrl: null,
    cloudFileName: null,
    members: new Map(),
    state: { playing: false, currentTime: 0, updatedAt: Date.now() },
  });
  res.json({ roomId: id, linkToken });
});

// Get room info (safe public fields)
roomRouter.get('/:id', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  res.json({
    id: room.id,
    sourceType: room.sourceType,
    cloudFileName: room.cloudFileName,
    cloudFileUrl: room.cloudFileUrl,
    memberCount: room.members.size,
    state: room.state,
  });
});

// Validate join token
roomRouter.get('/:id/join/:token', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  if (room.linkToken !== req.params.token) return res.status(403).json({ error: 'Invalid link' });
  res.json({ valid: true, roomId: room.id, sourceType: room.sourceType });
});

// Revoke + regenerate link
roomRouter.post('/:id/revoke', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  room.linkToken = nanoid(16);
  res.json({ linkToken: room.linkToken });
});
