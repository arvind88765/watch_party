import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import cors from 'cors';
import { roomRouter } from './routes/rooms.js';
import { uploadRouter } from './routes/upload.js';
import { handleWS } from './ws/handler.js';

const app = express();
const server = createServer(app);

const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',')
  : ['http://localhost:3000'];

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.some(o => origin.startsWith(o.trim()))) return cb(null, true);
    cb(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/api/rooms', roomRouter);
app.use('/api/upload', uploadRouter);

const wss = new WebSocketServer({ server, path: '/ws' });
wss.on('connection', (ws, req) => handleWS(ws, req, wss));

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => console.log(`Server running on :${PORT}`));
