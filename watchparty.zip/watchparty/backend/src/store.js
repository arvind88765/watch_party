// In-memory room store. In production, swap for Redis.
export const rooms = new Map();

// room shape:
// {
//   id: string,
//   hostId: string,
//   createdAt: number,
//   linkToken: string,  // rotatable shareable token
//   sourceType: 'local' | 'cloud',
//   cloudFileUrl: string | null,
//   cloudFileName: string | null,
//   members: Map<wsId, { id, name, ws }>
//   state: { playing: bool, currentTime: number, updatedAt: number }
// }
